@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Instalar Carteira no relogio
set "DEVICE=192.168.230.133:42873"
set "APK=%~dp0watch-wallet-debug.apk"
set "ADB=%~dp0adb.exe"
if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not exist "%ADB%" goto missing_adb
if not exist "%APK%" goto missing_apk

echo Conectando ao relogio em %DEVICE%...
"%ADB%" connect "%DEVICE%"
if errorlevel 1 goto connection_failed
"%ADB%" -s "%DEVICE%" get-state
if errorlevel 1 goto connection_failed

echo Confirmando que o dispositivo e um relogio...
"%ADB%" -s "%DEVICE%" shell pm list features | "%SystemRoot%\System32\findstr.exe" /x /c:"feature:android.hardware.type.watch" >nul
if errorlevel 1 goto not_watch

echo Instalando o APK...
"%ADB%" -s "%DEVICE%" install -r "%APK%"
if errorlevel 1 goto installation_failed

echo Abrindo o app no relogio...
"%ADB%" -s "%DEVICE%" shell am start -W -n br.com.aldsfmatao.watchwallet/.MainActivity
if errorlevel 1 goto launch_failed
echo.
echo Instalacao concluida. Confira o aplicativo no relogio.
echo O app abre a Carteira local; a verificacao do cartao depende do banco.
echo Desative a depuracao sem fio ao terminar, se nao for mais usa-la.
pause
exit /b 0

:missing_adb
echo ADB nao encontrado no Android SDK deste usuario nem ao lado deste arquivo.
echo Instale o Android SDK Platform-Tools oficial ou extraia seu conteudo aqui.
goto failure

:missing_apk
echo APK nao encontrado. Extraia TODO o ZIP para uma pasta antes de executar.
goto failure

:connection_failed
echo.
echo Nao foi possivel acessar o relogio. Confira Wi-Fi e depuracao sem fio.
echo Se ainda nao pareou este PC, no relogio toque em Parear novo dispositivo.
echo No Prompt de Comando execute o comando abaixo, substituindo a porta:
echo "%ADB%" pair 192.168.230.133:PORTA_DE_PAREAMENTO
echo A porta de pareamento e DIFERENTE da porta de conexao deste instalador.
echo Digite o codigo apenas quando o ADB pedir no seu PC. Nao envie o codigo.
echo Depois execute este instalador novamente.
echo Se IP ou porta de conexao mudou, use os comandos do LEIA-ME.txt.
goto failure

:not_watch
echo Nao foi possivel confirmar android.hardware.type.watch neste dispositivo.
echo Instalacao interrompida. Confira o endereco do relogio e sua conexao ADB.
goto failure

:installation_failed
echo A instalacao falhou. Leia o erro ADB acima.
echo Nenhum aplicativo foi desinstalado automaticamente.
goto failure

:launch_failed
echo O APK foi instalado, mas a abertura pelo ADB falhou.
echo Tente abrir Carteira no relogio na lista de aplicativos.
goto failure

:failure
echo.
echo Consulte LEIA-ME.txt. Nenhuma redefinicao ou desinstalacao foi executada.
pause
exit /b 1
