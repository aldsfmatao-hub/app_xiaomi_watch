@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
if not exist "%ADB%" set "ADB=%~dp0adb.exe"
set "BRIDGE_JAVA=%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe"
if not exist "%BRIDGE_JAVA%" goto find_java_home
goto java_ready
:find_java_home
if not defined JAVA_HOME goto missing_java
set "BRIDGE_JAVA=%JAVA_HOME%\bin\java.exe"
if not exist "%BRIDGE_JAVA%" goto missing_java
:java_ready
if not exist "%ADB%" goto missing_adb
if not exist "%~dp0WalletAdbBridge.java" goto missing_files
"%BRIDGE_JAVA%" --source 17 "%~dp0WalletAdbBridge.java" "%ADB%"
set "BRIDGE_RESULT=%ERRORLEVEL%"
pause
exit /b %BRIDGE_RESULT%
:missing_java
echo Java 17 ou posterior nao encontrado no Android Studio padrao nem em JAVA_HOME.
echo Consulte LEIA-ME.txt para executar com o caminho do JDK do seu Android Studio.
goto failure
:missing_adb
echo ADB nao encontrado. Confira o SDK do Android Studio ou coloque Platform-Tools nesta pasta.
goto failure
:missing_files
echo Extraia TODO o ZIP antes de executar.
:failure
pause
exit /b 1
