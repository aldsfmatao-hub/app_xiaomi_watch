import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.*;

/** Local navigation experiment. Does not provision, modify or authorize card tokens. */
public class WalletAdbBridge {
    static final List<String> WALLETS = List.of(
            "com.google.android.apps.walletnfcrel", "com.google.android.apps.gmoney");
    static final Set<String> BLOCKED_SCHEMES = Set.of(
            "http", "intent", "android-app", "file", "content", "data", "javascript",
            "tel", "sms", "smsto", "mailto", "market");
    static final Pattern DATA = Pattern.compile("(?:^|\\s)dat=([^\\s}]+)");
    static final Pattern COMPONENT = Pattern.compile("\\bcmp=([^\\s}]+)");
    static final Pattern EPOCH = Pattern.compile("^\\s*(\\d{9,12}\\.\\d{3,9})\\s");
    static final Scanner INPUT = new Scanner(System.in);
    static String adb;

    record Result(int code, String output) {}
    static class Problem extends Exception {
        Problem(String safeMessage) { super(safeMessage); }
    }

    static String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    static String usableUri(String value) throws Problem {
        if (value == null || value.isBlank() || value.length() > 16000
                || value.codePoints().anyMatch(c -> Character.isISOControl(c) || Character.isWhitespace(c))
                || value.contains("...") || value.contains("\u2026")
                || value.toLowerCase(Locale.ROOT).contains("redacted")) {
            throw new Problem("O link esta ausente, incompleto ou oculto pelo Android.");
        }
        try {
            URI uri = new URI(value);
            if (uri.getScheme() == null || BLOCKED_SCHEMES.contains(uri.getScheme().toLowerCase(Locale.ROOT))) {
                throw new Problem("Este tipo de URI nao e aceito neste teste de navegacao da Carteira.");
            }
            if (uri.getScheme().equalsIgnoreCase("https") && uri.getHost() == null) {
                throw new Problem("O link HTTPS nao tem um dominio valido.");
            }
        } catch (java.net.URISyntaxException invalid) {
            throw new Problem("O Android nao apresentou uma URI completa e valida.");
        }
        return value;
    }

    static Optional<String> dataFromStart(String line) {
        if (!isGoogleStart(line)) return Optional.empty();
        Matcher data = DATA.matcher(line);
        return data.find() ? Optional.of(data.group(1)) : Optional.empty();
    }

    static boolean isGoogleStart(String line) {
        if (!line.contains("START u")) return false;
        Matcher component = COMPONENT.matcher(line);
        if (!component.find()) return false;
        String target = component.group(1).split("/", 2)[0];
        return WALLETS.contains(target) || target.equals("com.google.android.gms");
    }

    static boolean freshLine(String line, BigDecimal start) {
        Matcher timestamp = EPOCH.matcher(line);
        return timestamp.find() && new BigDecimal(timestamp.group(1)).compareTo(start) >= 0;
    }

    static Result command(List<String> args) throws Exception {
        Process process = new ProcessBuilder(args).redirectErrorStream(true).start();
        ExecutorService worker = Executors.newSingleThreadExecutor();
        try {
            Future<String> output = worker.submit(() -> new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8));
            if (!process.waitFor(25, TimeUnit.SECONDS)) throw new Problem("ADB excedeu o tempo de resposta.");
            return new Result(process.exitValue(), output.get(5, TimeUnit.SECONDS));
        } finally {
            process.destroyForcibly();
            worker.shutdownNow();
        }
    }

    static Result adb(String serial, String... args) throws Exception {
        List<String> command = new ArrayList<>(List.of(adb));
        if (serial != null) command.addAll(List.of("-s", serial));
        command.addAll(List.of(args));
        return command(command);
    }

    static boolean isWatch(String serial) throws Exception {
        Result features = adb(serial, "shell", "pm list features");
        if (features.code != 0) throw new Problem("Nao foi possivel consultar os recursos do aparelho.");
        return features.output.lines().map(String::strip).anyMatch("feature:android.hardware.type.watch"::equals);
    }

    static void requireConnected(String serial) throws Exception {
        if (serial.isBlank() || serial.startsWith("-") || serial.codePoints().anyMatch(Character::isWhitespace)) {
            throw new Problem("Use exatamente um identificador listado por adb devices.");
        }
        Result state = adb(serial, "get-state");
        if (state.code != 0 || !state.output.strip().equals("device")) {
            throw new Problem("Aparelho nao conectado ou nao autorizado no ADB.");
        }
    }

    static Optional<String> observe(String source) throws Exception {
        Result clock = adb(source, "shell", "date '+%s.%N'");
        String time = clock.output.strip();
        if (clock.code != 0 || !time.matches("\\d{9,12}\\.\\d{1,9}")) {
            throw new Problem("Nao foi possivel obter o horario preciso do celular. A observacao nao iniciou.");
        }
        BigDecimal start = new BigDecimal(time).setScale(3, RoundingMode.CEILING);
        List<String> args = List.of(adb, "-s", source, "logcat", "-v", "epoch", "-T", start.toPlainString(),
                "ActivityTaskManager:V", "ActivityManager:V", "*:S");
        Process process = new ProcessBuilder(args).redirectErrorStream(true).start();
        ExecutorService worker = Executors.newSingleThreadExecutor();
        AtomicInteger received = new AtomicInteger();
        AtomicInteger fresh = new AtomicInteger();
        AtomicInteger starts = new AtomicInteger();
        AtomicInteger googleStarts = new AtomicInteger();
        AtomicInteger uris = new AtomicInteger();
        try {
            Future<Optional<String>> reader = worker.submit(() -> {
                try (BufferedReader lines = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = lines.readLine()) != null) {
                        if (line.isBlank() || line.startsWith("---------")) continue;
                        received.incrementAndGet();
                        // Keep even the very first event when it is newer than the device-time boundary.
                        if (!freshLine(line, start)) continue;
                        fresh.incrementAndGet();
                        if (line.contains("START u")) starts.incrementAndGet();
                        if (isGoogleStart(line)) googleStarts.incrementAndGet();
                        Optional<String> candidate = dataFromStart(line);
                        if (candidate.isPresent()) {
                            uris.incrementAndGet();
                            return candidate;
                        }
                    }
                }
                return Optional.empty();
            });
            System.out.println("Observando por 60 segundos. Agora toque em Adicionar/Verificar no relogio.");
            System.out.println("Somente links visiveis em aberturas da Carteira/Google Play services serao considerados.");
            try {
                Optional<String> result = reader.get(Duration.ofSeconds(60).toMillis(), TimeUnit.MILLISECONDS);
                if (result.isEmpty()) process.waitFor(500, TimeUnit.MILLISECONDS);
                if (!process.isAlive() && process.exitValue() != 0) {
                    throw new Problem("O Android/ADB encerrou o logcat com erro. A captura ficou indisponivel.");
                }
                return result;
            }
            catch (TimeoutException timeout) { return Optional.empty(); }
        } finally {
            process.destroyForcibly();
            worker.shutdownNow();
            System.out.println("DIAGNOSTICO: registros recebidos=" + received.get()
                    + "; novos=" + fresh.get() + "; START=" + starts.get()
                    + "; Wallet/Google=" + googleStarts.get() + "; URI=" + uris.get());
        }
    }

    static boolean resolveOutput(String packageName, String output) {
        return output.lines().map(String::strip).anyMatch(line ->
                line.matches(Pattern.quote(packageName) + "/[A-Za-z0-9_.$]+"));
    }

    static void relay(String watch, String rawUri) throws Exception {
        String uri = usableUri(rawUri);
        String arguments = "-a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d " + shellQuote(uri);
        for (String packageName : WALLETS) {
            Result resolve = adb(watch, "shell", "cmd package resolve-activity --brief " + arguments + " -p " + packageName);
            if (resolve.code != 0 || !resolveOutput(packageName, resolve.output)) continue;
            System.out.println("A Carteira instalada no relogio declara um receptor para este link.");
            Result start = adb(watch, "shell", "am start -W " + arguments + " -p " + packageName);
            // am start echoes the full URI. Do not print or save its raw output.
            if (start.code != 0 || start.output.contains("Error:") || start.output.contains("Exception")) {
                throw new Problem("O Android recusou a abertura. Nenhuma permissao interna foi contornada.");
            }
            System.out.println("ADB enviou o link para a Carteira do relogio. Confira a tela fisica.");
            System.out.println("Isso nao confirma ativacao do cartao nem alteracao do dispositivo vinculado ao pedido.");
            return;
        }
        throw new Problem("A Carteira do relogio nao anunciou um receptor para esse link. Nada foi redirecionado.");
    }

    static void check(boolean value) {
        if (!value) throw new AssertionError("Self-test failed");
    }

    static void selfTest() throws Exception {
        check(shellQuote("https://pay.google.com/a?x=1&y=2").equals("'https://pay.google.com/a?x=1&y=2'"));
        check(shellQuote("a'b;$(id)").equals("'a'\\''b;$(id)'"));
        check(usableUri("https://pay.google.com/path?opaque=example").endsWith("opaque=example"));
        for (String invalid : List.of("", "https://pay.google.com/...", "javascript:alert(1)",
                "intent://x#Intent;end", "http://pay.google.com/", "https://x/\nextra", "https:///missing")) {
            boolean rejected = false;
            try { usableUri(invalid); } catch (Problem expected) { rejected = true; }
            check(rejected);
        }
        String start = "START u0 {act=android.intent.action.VIEW dat=https://pay.google.com/test?opaque=example cmp=com.google.android.apps.walletnfcrel/.Example}";
        check(dataFromStart(start).orElseThrow().equals("https://pay.google.com/test?opaque=example"));
        check(dataFromStart(start.replace("walletnfcrel", "other")).isEmpty());
        check(dataFromStart(start.replace("START u0", "OLD RECORD")).isEmpty());
        check(dataFromStart("START u0 {act=android.intent.action.MAIN cmp=com.google.android.apps.walletnfcrel/.Example (has extras)}").isEmpty());
        check(resolveOutput(WALLETS.get(0), WALLETS.get(0) + "/.Example"));
        check(!resolveOutput(WALLETS.get(0), "com.example.other/.Example"));
        BigDecimal boundary = new BigDecimal("1792060000.123");
        check(freshLine("1792060000.124  100 100 I Tag: " + start, boundary));
        check(!freshLine("1792060000.122  100 100 I Tag: " + start, boundary));
        check(freshLine("1792060000.123  100 100 I Tag: " + start, boundary));
        check(!freshLine("unformatted " + start, boundary));
        System.out.println("20 self-tests passed: URI parsing, target filtering, shell quoting and capture timestamps.");
    }

    public static void main(String[] args) {
        try {
            if (args.length == 1 && args[0].equals("--self-test")) { selfTest(); return; }
            if (args.length != 1) throw new Problem("Inicie pelo arquivo ABRIR-PONTE-ADB.cmd.");
            adb = args[0];
            System.out.println("PONTE ADB EXPERIMENTAL v2 - somente navegacao, sem ativacao bancaria");
            System.out.println("Nenhum log, URL ou codigo sera salvo em arquivo por esta ferramenta.");
            Result devices = adb(null, "devices");
            if (devices.code != 0) throw new Problem("ADB nao iniciou.");
            System.out.println(devices.output);
            System.out.print("Serial do RELOGIO (IP:porta atual): ");
            String watch = INPUT.nextLine().strip();
            requireConnected(watch);
            if (!isWatch(watch)) throw new Problem("O destino selecionado nao informa ser um relogio.");
            System.out.print("Serial do CELULAR ou EMULADOR que recebe o encaminhamento: ");
            String source = INPUT.nextLine().strip();
            requireConnected(source);
            if (isWatch(source)) throw new Problem("A origem deve ser o celular/emulador, nao outro identificador do relogio.");
            System.out.println("O emulador so serve se o fluxo realmente ocorrer nele. Nao muda o pareamento do relogio.");
            System.out.println("Deixe o fluxo pronto no relogio. Pressione Enter para iniciar a observacao.");
            INPUT.nextLine();
            Optional<String> candidate = observe(source);
            if (candidate.isEmpty()) {
                throw new Problem("Nenhum link completo ficou visivel nesta observacao. O Android pode ocultar dados ou usar extras/IPC; o teste nao prova ausencia de um link.");
            }
            relay(watch, candidate.get());
        } catch (Problem problem) {
            System.err.println(problem.getMessage());
            System.exit(1);
        } catch (Exception failure) {
            // Exceptions and ADB output may contain full URLs. Never dump them to the console.
            System.err.println("Nao foi possivel concluir o teste (" + failure.getClass().getSimpleName() + ").");
            System.exit(1);
        }
    }
}
